const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');

const obfuscateFile = (filePath) => {
  const code = fs.readFileSync(filePath, 'utf8');
  const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, {
    // Configurações de ofuscação
  }).getObfuscatedCode();
  fs.writeFileSync(filePath, obfuscatedCode);
};

const obfuscateDir = (dir) => {
  const files = fs.readdirSync(dir);
  files.forEach(file => {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      obfuscateDir(filePath);
    } else if (file.endsWith('.js') || file.endsWith('.ts')) {
      obfuscateFile(filePath);
    }
  });
};

obfuscateDir('./dist'); 