export const roadmap = [
  {
    phase: 'MVP (Semana 1)',
    features: [
      'Login Discord',
      'Criar Bot Básico',
      'Templates Simples',
      'Dashboard Básico'
    ]
  },
  {
    phase: 'Fase 2 (Semana 2)',
    features: [
      'Construtor Visual',
      'Mais Templates',
      'Métricas Básicas'
    ]
  },
  {
    phase: 'Fase 3 (Semana 3)',
    features: [
      'Sistema de Pagamento',
      'Recursos Premium',
      'Suporte ao Cliente'
    ]
  }
]; 