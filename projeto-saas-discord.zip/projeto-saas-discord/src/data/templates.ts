export const botTemplates = [
  {
    id: 'moderation',
    name: 'Moderação Completa',
    description: 'Bot focado em moderação com sistemas anti-spam, filtros e logs',
    commands: [
      {
        name: 'warn',
        description: 'Avisar usuário',
        options: [
          { name: 'user', type: 'USER', required: true },
          { name: 'reason', type: 'STRING', required: true }
        ]
      },
      // ... mais comandos
    ],
    features: ['anti-spam', 'word-filter', 'raid-protection']
  },
  // ... outros templates
]; 