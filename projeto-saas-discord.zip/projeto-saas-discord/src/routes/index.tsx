import { createBrowserRouter } from 'react-router-dom';
import App from '../App';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { AdminDashboard } from '../pages/admin/Dashboard';
import { UserDashboard } from '../pages/dashboard/UserDashboard';
import { TemplateGallery } from '../components/TemplateGallery';
import { Settings } from '../pages/Settings';
import { Analytics } from '../pages/Analytics';
import { Chat } from '../pages/Chat';
import { Help } from '../pages/Help';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
  },
  {
    path: '/',
    element: <DashboardLayout />,
    children: [
      {
        path: 'dashboard',
        element: <UserDashboard />,
      },
      {
        path: 'admin',
        element: <AdminDashboard />,
      },
      {
        path: 'templates',
        element: <TemplateGallery />,
      },
      {
        path: 'settings',
        element: <Settings />,
      },
      {
        path: 'analytics',
        element: <Analytics />,
      },
      {
        path: 'chat',
        element: <Chat />,
      },
      {
        path: 'help',
        element: <Help />,
      },
    ],
  },
]); 