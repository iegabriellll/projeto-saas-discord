import { Outlet, Link } from 'react-router-dom';
import { 
  Bot, 
  LayoutDashboard,
  Users, 
  Settings, 
  BookTemplate,
  BarChart,
  MessageSquare,
  HelpCircle
} from 'lucide-react';
import { DashboardHeader } from '../components/DashboardHeader';

export function DashboardLayout() {
  return (
    <div className="flex h-screen bg-indigo-950 text-white">
      {/* Sidebar */}
      <aside className="w-64 bg-indigo-900/50 p-4">
        <div className="flex items-center gap-2 mb-8">
          <Bot className="h-8 w-8 text-indigo-300" />
          <span className="text-xl font-bold">DiscordAutomator</span>
        </div>

        <nav className="space-y-6">
          <div>
            <p className="text-xs uppercase text-indigo-400 font-medium mb-2">Geral</p>
            <div className="space-y-1">
              <NavLink to="/dashboard" icon={<LayoutDashboard />}>Dashboard</NavLink>
              <NavLink to="/templates" icon={<BookTemplate />}>Templates</NavLink>
              <NavLink to="/analytics" icon={<BarChart />}>Analytics</NavLink>
            </div>
          </div>

          <div>
            <p className="text-xs uppercase text-indigo-400 font-medium mb-2">Administração</p>
            <div className="space-y-1">
              <NavLink to="/admin" icon={<Users />}>Usuários</NavLink>
              <NavLink to="/settings" icon={<Settings />}>Configurações</NavLink>
            </div>
          </div>

          <div>
            <p className="text-xs uppercase text-indigo-400 font-medium mb-2">Suporte</p>
            <div className="space-y-1">
              <NavLink to="/chat" icon={<MessageSquare />}>Chat</NavLink>
              <NavLink to="/help" icon={<HelpCircle />}>Ajuda</NavLink>
            </div>
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <DashboardHeader />
        <main className="flex-1 overflow-auto bg-indigo-950 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function NavLink({ to, icon, children }: { to: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-indigo-800/50 transition-colors text-indigo-300 hover:text-white"
    >
      {icon}
      <span>{children}</span>
    </Link>
  );
} 