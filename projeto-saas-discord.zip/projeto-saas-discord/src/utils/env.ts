const encryptedEnv = {
  DISCORD_CLIENT_ID: 'encrypted_value_here',
  DISCORD_CLIENT_SECRET: 'encrypted_value_here',
  // ...
};

export const getEnvVar = (key: string) => {
  if (import.meta.env.PROD) {
    return encryption.decrypt(encryptedEnv[key]);
  }
  return import.meta.env[key];
}; 