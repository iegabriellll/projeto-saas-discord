export const launchChecklist = [
  {
    title: 'Landing Page',
    tasks: [
      'Design responsivo',
      'Formulário de waitlist',
      'SEO básico',
      'Analytics'
    ]
  },
  {
    title: 'Autenticação',
    tasks: [
      'Login Discord',
      'Persistência de sessão',
      'Proteção de rotas'
    ]
  },
  {
    title: 'Core Features',
    tasks: [
      'Criar bot',
      'Templates básicos',
      'Dashboard simples'
    ]
  },
  {
    title: 'Infraestrutura',
    tasks: [
      'Deploy Frontend (Vercel)',
      'Deploy Backend (Railway)',
      'Banco de Dados',
      'Monitoramento'
    ]
  }
]; 