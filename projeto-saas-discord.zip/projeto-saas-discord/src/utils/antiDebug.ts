export const setupAntiDebug = () => {
  const antiDebug = () => {
    const start = performance.now();
    debugger;
    const end = performance.now();
    
    if (end - start > 100) {
      window.location.href = '/error';
    }
  };

  setInterval(antiDebug, 1000);
  
  // Desabilitar devtools
  document.addEventListener('keydown', (e) => {
    if (
      e.key === 'F12' || 
      (e.ctrlKey && e.shiftKey && e.key === 'I') ||
      (e.ctrlKey && e.shiftKey && e.key === 'J') ||
      (e.ctrlKey && e.key === 'U')
    ) {
      e.preventDefault();
    }
  });
}; 