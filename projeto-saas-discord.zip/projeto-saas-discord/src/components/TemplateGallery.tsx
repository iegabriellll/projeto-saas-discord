import { useState } from 'react';

const templates = [
  {
    id: 'welcome',
    name: 'Bot de Boas-vindas',
    description: 'Mensagens personalizadas para novos membros',
    commands: [/* ... */]
  },
  {
    id: 'moderation',
    name: 'Moderação Automática',
    description: 'Filtros e regras de moderação',
    commands: [/* ... */]
  }
];

export function TemplateGallery() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {templates.map(template => (
        <div key={template.id} className="bg-indigo-900/50 p-6 rounded-lg">
          <h3 className="text-xl font-bold mb-2">{template.name}</h3>
          <p className="text-indigo-300 mb-4">{template.description}</p>
          <button className="btn-primary">Usar Template</button>
        </div>
      ))}
    </div>
  );
} 