import { Check, X } from 'lucide-react';

const plans = [
  {
    name: "Gratuito",
    features: {
      "Bots por servidor": "1",
      "Número de servidores": "2",
      "Templates": "Básicos",
      "Painel de controle": "Básico",
      "Suporte": "Comunidade",
      "Integrações": "Não",
      "GPT": "Não",
      "Webhooks": "Não",
      "SLA": "Não"
    }
  },
  {
    name: "Pro",
    features: {
      "Bots por servidor": "Ilimitado",
      "Número de servidores": "10",
      "Templates": "Todos",
      "Painel de controle": "Avançado",
      "Suporte": "Prioritário",
      "Integrações": "Sim",
      "GPT": "Básico",
      "Webhooks": "5 por bot",
      "SLA": "99.5%"
    }
  },
  {
    name: "Empresarial",
    features: {
      "Bots por servidor": "Ilimitado",
      "Número de servidores": "Ilimitado",
      "Templates": "Personalizados",
      "Painel de controle": "Completo",
      "Suporte": "24/7 Dedicado",
      "Integrações": "Ilimitadas",
      "GPT": "Avançado",
      "Webhooks": "Ilimitados",
      "SLA": "99.9%"
    }
  }
];

export function PlanComparison() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-indigo-700">
            <th className="p-4 text-left">Recursos</th>
            {plans.map(plan => (
              <th key={plan.name} className="p-4 text-center">{plan.name}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.keys(plans[0].features).map(feature => (
            <tr key={feature} className="border-b border-indigo-800/30">
              <td className="p-4">{feature}</td>
              {plans.map(plan => (
                <td key={`${plan.name}-${feature}`} className="p-4 text-center">
                  {plan.features[feature] === "Sim" ? (
                    <Check className="h-5 w-5 text-green-400 mx-auto" />
                  ) : plan.features[feature] === "Não" ? (
                    <X className="h-5 w-5 text-red-400 mx-auto" />
                  ) : (
                    plan.features[feature]
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
} 