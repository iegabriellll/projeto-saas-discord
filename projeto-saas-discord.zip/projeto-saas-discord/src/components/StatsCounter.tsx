import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export function StatsCounter() {
  const [counts, setCounts] = useState({
    users: 0,
    bots: 0,
    messages: 0
  });

  useEffect(() => {
    // Simular dados - substituir por API real
    const targetCounts = {
      users: 15000,
      bots: 25000,
      messages: 1000000
    };

    const duration = 2000; // 2 segundos
    const steps = 60;
    const interval = duration / steps;

    const increment = {
      users: targetCounts.users / steps,
      bots: targetCounts.bots / steps,
      messages: targetCounts.messages / steps
    };

    let step = 0;
    const timer = setInterval(() => {
      if (step < steps) {
        setCounts(prev => ({
          users: Math.min(Math.round(increment.users * (step + 1)), targetCounts.users),
          bots: Math.min(Math.round(increment.bots * (step + 1)), targetCounts.bots),
          messages: Math.min(Math.round(increment.messages * (step + 1)), targetCounts.messages)
        }));
        step++;
      } else {
        clearInterval(timer);
      }
    }, interval);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-indigo-900/50 p-6 rounded-lg"
      >
        <h3 className="text-4xl font-bold mb-2">{counts.users.toLocaleString()}</h3>
        <p className="text-indigo-300">Usuários Ativos</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-indigo-900/50 p-6 rounded-lg"
      >
        <h3 className="text-4xl font-bold mb-2">{counts.bots.toLocaleString()}</h3>
        <p className="text-indigo-300">Bots Criados</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-indigo-900/50 p-6 rounded-lg"
      >
        <h3 className="text-4xl font-bold mb-2">{counts.messages.toLocaleString()}</h3>
        <p className="text-indigo-300">Mensagens Processadas</p>
      </motion.div>
    </div>
  );
} 