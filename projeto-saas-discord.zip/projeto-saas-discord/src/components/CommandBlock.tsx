import { Draggable } from 'react-beautiful-dnd';
import { MessageSquare, Shield, Zap, Settings } from 'lucide-react';

interface CommandBlockProps {
  type: 'message' | 'reaction' | 'moderation' | 'custom';
}

const icons = {
  message: MessageSquare,
  reaction: Zap,
  moderation: Shield,
  custom: Settings,
};

export function CommandBlock({ type }: CommandBlockProps) {
  const Icon = icons[type];

  return (
    <div className="bg-indigo-700/50 p-4 rounded-lg cursor-move">
      <div className="flex items-center gap-2">
        <Icon className="h-5 w-5" />
        <span className="capitalize">{type}</span>
      </div>
    </div>
  );
} 