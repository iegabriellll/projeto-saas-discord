import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';

const commandBlocks = {
  message: {
    type: 'message',
    fields: ['content', 'channel', 'embed'],
    template: { content: '', channel: 'general' }
  },
  role: {
    type: 'role',
    fields: ['role', 'condition'],
    template: { role: '', condition: 'join' }
  },
  moderation: {
    type: 'moderation',
    fields: ['action', 'duration'],
    template: { action: 'warn', duration: '1h' }
  }
}; 