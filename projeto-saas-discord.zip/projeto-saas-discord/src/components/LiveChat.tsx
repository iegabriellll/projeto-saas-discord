import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X } from "lucide-react";

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 p-4 bg-indigo-600 rounded-full shadow-lg hover:bg-indigo-500 transition-colors"
      >
        <MessageCircle className="h-6 w-6" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-20 right-4 w-80 bg-indigo-900 rounded-lg shadow-xl"
          >
            <div className="p-4 border-b border-indigo-800 flex justify-between items-center">
              <h3 className="font-bold">Suporte</h3>
              <button onClick={() => setIsOpen(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="h-96 p-4">
              {/* Implementar chat aqui */}
              <p className="text-center text-indigo-300">
                Em breve: Chat com suporte 24/7
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
} 