import { Play } from 'lucide-react';

export function DemoButton() {
  return (
    <button 
      onClick={() => window.open('/demo', '_blank')}
      className="group px-6 py-3 rounded-md bg-white text-indigo-900 hover:bg-indigo-100 transition-colors font-bold text-lg flex items-center gap-2"
    >
      <Play className="h-5 w-5" />
      Ver Demonstração
    </button>
  );
} 