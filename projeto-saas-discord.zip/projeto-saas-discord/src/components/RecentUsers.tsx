import { User } from 'lucide-react';

const recentUsers = [
  { id: 1, name: 'João Silva', email: 'joao@email.com', date: '2024-03-20' },
  { id: 2, name: 'Maria Santos', email: 'maria@email.com', date: '2024-03-19' },
  { id: 3, name: 'Pedro Costa', email: 'pedro@email.com', date: '2024-03-18' },
];

export function RecentUsers() {
  return (
    <div className="bg-indigo-900/50 p-6 rounded-lg">
      <h2 className="text-xl font-bold mb-4">Novos Usuários</h2>
      <div className="space-y-4">
        {recentUsers.map(user => (
          <div 
            key={user.id}
            className="flex items-center gap-3 p-3 bg-indigo-800/50 rounded-lg"
          >
            <div className="p-2 bg-indigo-700 rounded-full">
              <User className="h-5 w-5 text-indigo-300" />
            </div>
            <div>
              <h3 className="font-medium">{user.name}</h3>
              <p className="text-sm text-indigo-300">{user.email}</p>
            </div>
            <span className="ml-auto text-sm text-indigo-400">
              {new Date(user.date).toLocaleDateString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
} 