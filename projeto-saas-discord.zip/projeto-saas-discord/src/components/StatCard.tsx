import { ReactNode } from 'react';

interface StatCardProps {
  icon: ReactNode;
  title: string;
  value: number | string;
}

export function StatCard({ icon, title, value }: StatCardProps) {
  return (
    <div className="bg-indigo-900/50 p-6 rounded-lg">
      <div className="flex items-center gap-3 mb-4">
        {icon}
        <h3 className="text-lg font-medium">{title}</h3>
      </div>
      <p className="text-3xl font-bold">{value}</p>
    </div>
  );
} 