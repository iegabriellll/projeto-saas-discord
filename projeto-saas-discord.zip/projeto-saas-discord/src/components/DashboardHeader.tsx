import { ChevronLeft, Bell, Search, User } from 'lucide-react';
import { Link } from 'react-router-dom';

export function DashboardHeader() {
  return (
    <header className="bg-indigo-900/50 border-b border-indigo-800 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link 
            to="/" 
            className="flex items-center gap-2 text-indigo-300 hover:text-white transition-colors"
          >
            <ChevronLeft className="h-5 w-5" />
            <span>Voltar ao início</span>
          </Link>

          <div className="relative ml-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-indigo-400" />
            <input 
              type="text"
              placeholder="Buscar..."
              className="pl-10 pr-4 py-2 bg-indigo-800/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 w-64"
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="relative p-2 hover:bg-indigo-800/50 rounded-lg transition-colors">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full"></span>
          </button>
          
          <div className="flex items-center gap-3 p-2 hover:bg-indigo-800/50 rounded-lg transition-colors cursor-pointer">
            <div className="h-8 w-8 bg-indigo-700 rounded-full flex items-center justify-center">
              <User className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium">Admin</p>
              <p className="text-xs text-indigo-300">admin@discord.com</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
} 