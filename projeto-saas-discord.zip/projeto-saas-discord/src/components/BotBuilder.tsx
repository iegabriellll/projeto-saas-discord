import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { CommandBlock } from './CommandBlock';

export function BotBuilder() {
  return (
    <div className="h-full flex">
      <div className="w-64 bg-indigo-800 p-4">
        <h3 className="text-lg font-bold mb-4">Blocos</h3>
        <div className="space-y-2">
          <CommandBlock type="message" />
          <CommandBlock type="reaction" />
          <CommandBlock type="moderation" />
          <CommandBlock type="custom" />
        </div>
      </div>

      <DragDropContext onDragEnd={() => {}}>
        <div className="flex-1 p-6">
          <Droppable droppableId="flow">
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className="min-h-full bg-indigo-950/50 rounded-lg p-4"
              >
                {/* Área onde os blocos serão soltos */}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </div>
      </DragDropContext>
    </div>
  );
} 