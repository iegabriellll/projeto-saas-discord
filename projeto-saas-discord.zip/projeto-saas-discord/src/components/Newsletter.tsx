import { useState } from "react";
import { motion } from "framer-motion";
import { Send } from "lucide-react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    
    try {
      // Implementar integração com serviço de email
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStatus("success");
      setEmail("");
    } catch (error) {
      setStatus("error");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-indigo-900/50 p-8 rounded-lg max-w-md mx-auto"
    >
      <h3 className="text-2xl font-bold mb-4">Fique por dentro das novidades</h3>
      <p className="text-indigo-200 mb-6">
        Receba atualizações sobre novos recursos e dicas para automatizar seu Discord.
      </p>
      
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Seu melhor e-mail"
          className="flex-1 px-4 py-2 rounded bg-indigo-800/50 border border-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          required
        />
        <button
          type="submit"
          disabled={status === "loading"}
          className="px-4 py-2 bg-indigo-600 rounded hover:bg-indigo-500 transition-colors disabled:opacity-50"
        >
          {status === "loading" ? "Enviando..." : <Send className="h-5 w-5" />}
        </button>
      </form>
      
      {status === "success" && (
        <p className="text-green-400 mt-2">Inscrição realizada com sucesso!</p>
      )}
      {status === "error" && (
        <p className="text-red-400 mt-2">Erro ao realizar inscrição. Tente novamente.</p>
      )}
    </motion.div>
  );
} 