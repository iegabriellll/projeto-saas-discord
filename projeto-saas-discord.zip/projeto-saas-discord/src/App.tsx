import { 
  Bot, 
  Calendar, 
  Code, 
  Command, 
  Cpu, 
  Layers, 
  MessageSquare, 
  Rocket, 
  Shield, 
  Sparkles, 
  Webhook 
} from 'lucide-react';
import { PlanComparison } from "./components/PlanComparison";
import { StatsCounter } from "./components/StatsCounter";
import { Link } from 'react-router-dom';

function App() {
  return (
    <>
      <div className="min-h-screen bg-gradient-to-b from-indigo-900 to-purple-900 text-white">
        {/* Header/Navigation */}
        <header className="container mx-auto py-6 px-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Bot className="h-8 w-8 text-indigo-300" />
            <span className="text-2xl font-bold">DiscordAutomator</span>
          </div>
          <nav>
            <ul className="flex space-x-8">
              <li><a href="#features" className="hover:text-indigo-300 transition-colors">Recursos</a></li>
              <li><a href="#pricing" className="hover:text-indigo-300 transition-colors">Preços</a></li>
              <li><a href="#templates" className="hover:text-indigo-300 transition-colors">Templates</a></li>
              <li><a href="#faq" className="hover:text-indigo-300 transition-colors">FAQ</a></li>
            </ul>
          </nav>
          <div className="flex space-x-4">
            <Link 
              to="/dashboard"
              className="px-4 py-2 rounded-md bg-transparent border border-indigo-300 text-indigo-300 hover:bg-indigo-300 hover:text-indigo-900 transition-colors"
            >
              Login
            </Link>
            <Link
              to="/dashboard"
              className="px-4 py-2 rounded-md bg-indigo-500 text-white hover:bg-indigo-600 transition-colors"
            >
              Registrar
            </Link>
          </div>
        </header>

        {/* Hero Section */}
        <section className="container mx-auto px-4 py-20 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-5xl font-bold mb-6">Automatize seu servidor Discord sem código</h1>
            <p className="text-xl mb-8 text-indigo-200">
              Crie bots personalizados, automatize tarefas e melhore a experiência da sua comunidade com nossa plataforma intuitiva de arrastar e soltar.
            </p>
            <div className="flex space-x-4">
              <button className="px-6 py-3 rounded-md bg-indigo-500 text-white hover:bg-indigo-600 transition-colors font-medium">
                Começar Gratuitamente
              </button>
              <button className="px-6 py-3 rounded-md bg-transparent border border-indigo-300 text-indigo-300 hover:bg-indigo-300 hover:text-indigo-900 transition-colors font-medium">
                Ver Demonstração
              </button>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80" 
              alt="Discord Bot Dashboard" 
              className="rounded-lg shadow-2xl"
            />
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 bg-indigo-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Recursos Poderosos</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Nossa plataforma oferece tudo o que você precisa para criar e gerenciar bots Discord avançados sem precisar escrever uma linha de código.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Command className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Criador de Bots Visual</h3>
                <p className="text-indigo-200">
                  Interface intuitiva de arrastar e soltar para criar bots personalizados sem conhecimento técnico.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Layers className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Templates Prontos</h3>
                <p className="text-indigo-200">
                  Dezenas de templates pré-configurados para moderação, música, economia, jogos e muito mais.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Cpu className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Painel de Controle</h3>
                <p className="text-indigo-200">
                  Monitore o desempenho, visualize logs e gerencie seus bots em tempo real através de um painel completo.
                </p>
              </div>

              {/* Feature 4 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Webhook className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Webhooks e Integrações</h3>
                <p className="text-indigo-200">
                  Conecte seu bot a serviços externos como GitHub, Twitter e outras plataformas através de webhooks.
                </p>
              </div>

              {/* Feature 5 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Calendar className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Tarefas Agendadas</h3>
                <p className="text-indigo-200">
                  Agende mensagens e ações para serem executadas automaticamente em horários específicos.
                </p>
              </div>

              {/* Feature 6 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="bg-indigo-700/50 p-3 rounded-full w-fit mb-6">
                  <Sparkles className="h-8 w-8 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Integração com GPT</h3>
                <p className="text-indigo-200">
                  Crie respostas inteligentes e personalizadas utilizando a tecnologia GPT para interagir com os usuários.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Como Funciona</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Comece a automatizar seu servidor Discord em apenas três passos simples.
              </p>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="md:w-1/3 text-center p-6">
                <div className="bg-indigo-700/50 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <Bot className="h-10 w-10 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">1. Conecte sua conta</h3>
                <p className="text-indigo-200">
                  Faça login com sua conta Discord e selecione os servidores que deseja automatizar.
                </p>
              </div>

              <div className="md:w-1/3 text-center p-6">
                <div className="bg-indigo-700/50 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <Code className="h-10 w-10 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">2. Crie seu bot</h3>
                <p className="text-indigo-200">
                  Use nosso editor visual para criar seu bot ou escolha um dos nossos templates prontos.
                </p>
              </div>

              <div className="md:w-1/3 text-center p-6">
                <div className="bg-indigo-700/50 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <Rocket className="h-10 w-10 text-indigo-300" />
                </div>
                <h3 className="text-2xl font-bold mb-3">3. Ative e gerencie</h3>
                <p className="text-indigo-200">
                  Ative seu bot com um clique e gerencie-o através do nosso painel de controle intuitivo.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-indigo-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Números que Impressionam</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Veja o impacto que estamos causando na comunidade Discord.
              </p>
            </div>
            <StatsCounter />
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-20 bg-indigo-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Planos e Preços</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Escolha o plano que melhor atende às necessidades da sua comunidade.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Free Plan */}
              <div className="bg-indigo-900/50 p-8 rounded-lg border border-indigo-700 hover:border-indigo-500 transition-colors">
                <h3 className="text-2xl font-bold mb-2">Gratuito</h3>
                <p className="text-indigo-300 mb-6">Para comunidades pequenas</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$0</span>
                  <span className="text-indigo-300">/mês</span>
                </div>
                <ul className="mb-8 space-y-3">
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>1 bot por servidor</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Até 2 servidores</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Templates básicos</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Painel de controle básico</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Suporte comunitário</span>
                  </li>
                </ul>
                <button className="w-full px-6 py-3 rounded-md bg-transparent border border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-colors font-medium">
                  Começar Grátis
                </button>
              </div>

              {/* Pro Plan */}
              <div className="bg-indigo-800/50 p-8 rounded-lg border-2 border-indigo-500 transform scale-105 shadow-xl">
                <div className="bg-indigo-500 text-white text-sm font-bold uppercase py-1 px-4 rounded-full w-fit mb-4">
                  Mais Popular
                </div>
                <h3 className="text-2xl font-bold mb-2">Pro</h3>
                <p className="text-indigo-300 mb-6">Para comunidades em crescimento</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$29</span>
                  <span className="text-indigo-300">/mês</span>
                </div>
                <ul className="mb-8 space-y-3">
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Bots ilimitados</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Até 10 servidores</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Todos os templates</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Painel de controle avançado</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Integração com GPT</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Suporte prioritário</span>
                  </li>
                </ul>
                <button className="w-full px-6 py-3 rounded-md bg-indigo-500 text-white hover:bg-indigo-600 transition-colors font-medium">
                  Assinar Agora
                </button>
              </div>

              {/* Enterprise Plan */}
              <div className="bg-indigo-900/50 p-8 rounded-lg border border-indigo-700 hover:border-indigo-500 transition-colors">
                <h3 className="text-2xl font-bold mb-2">Empresarial</h3>
                <p className="text-indigo-300 mb-6">Para grandes comunidades</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$99</span>
                  <span className="text-indigo-300">/mês</span>
                </div>
                <ul className="mb-8 space-y-3">
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Bots ilimitados</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Servidores ilimitados</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Templates personalizados</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Painel de controle completo</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Integração com GPT avançada</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>Suporte dedicado 24/7</span>
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-5 w-5 text-indigo-400 mr-2" />
                    <span>SLA garantido</span>
                  </li>
                </ul>
                <button className="w-full px-6 py-3 rounded-md bg-transparent border border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-colors font-medium">
                  Fale Conosco
                </button>
              </div>
            </div>

            <div className="mt-16">
              <h3 className="text-2xl font-bold mb-8 text-center">Compare os Planos</h3>
              <PlanComparison />
            </div>
          </div>
        </section>

        {/* Templates Section */}
        <section id="templates" className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Templates Populares</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Comece rapidamente com nossos templates pré-configurados para diversas necessidades.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Template 1 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-indigo-700/50 p-3 rounded-full">
                    <Shield className="h-6 w-6 text-indigo-300" />
                  </div>
                  <span className="bg-indigo-700/50 text-xs font-medium py-1 px-2 rounded-full">
                    Popular
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-2">Moderação Completa</h3>
                <p className="text-indigo-200 mb-4">
                  Sistema completo de moderação com filtro de palavras, anti-spam, avisos e punições automáticas.
                </p>
                <button className="w-full px-4 py-2 rounded-md bg-transparent border border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-colors">
                  Ver Detalhes
                </button>
              </div>

              {/* Template 2 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-indigo-700/50 p-3 rounded-full">
                    <MessageSquare className="h-6 w-6 text-indigo-300" />
                  </div>
                  <span className="bg-indigo-700/50 text-xs font-medium py-1 px-2 rounded-full">
                    Novo
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-2">Assistente GPT</h3>
                <p className="text-indigo-200 mb-4">
                  Bot inteligente que responde perguntas, fornece informações e ajuda os membros do servidor.
                </p>
                <button className="w-full px-4 py-2 rounded-md bg-transparent border border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-colors">
                  Ver Detalhes
                </button>
              </div>

              {/* Template 3 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg hover:bg-indigo-800/50 transition-colors">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-indigo-700/50 p-3 rounded-full">
                    <Calendar className="h-6 w-6 text-indigo-300" />
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">Eventos e Agendamentos</h3>
                <p className="text-indigo-200 mb-4">
                  Organize eventos, envie lembretes e gerencie inscrições automaticamente no seu servidor.
                </p>
                <button className="w-full px-4 py-2 rounded-md bg-transparent border border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-colors">
                  Ver Detalhes
                </button>
              </div>
            </div>

            <div className="text-center mt-12">
              <button className="px-6 py-3 rounded-md bg-indigo-700 text-white hover:bg-indigo-600 transition-colors font-medium">
                Ver Todos os Templates
              </button>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-indigo-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">O Que Nossos Clientes Dizem</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Veja como nossa plataforma tem ajudado comunidades a crescer e se engajar.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Testimonial 1 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80" 
                    alt="Avatar" 
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-bold">Carlos Silva</h4>
                    <p className="text-indigo-300 text-sm">Comunidade de Jogos</p>
                  </div>
                </div>
                <p className="text-indigo-200">
                  "Nossa comunidade cresceu 200% desde que começamos a usar o DiscordAutomator. Os membros adoram as interações automáticas e os eventos agendados."
                </p>
              </div>

              {/* Testimonial 2 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80" 
                    alt="Avatar" 
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-bold">Ana Martins</h4>
                    <p className="text-indigo-300 text-sm">Criadora de Conteúdo</p>
                  </div>
                </div>
                <p className="text-indigo-200">
                  "A integração com GPT revolucionou a forma como interajo com meus seguidores. Agora posso focar na criação de conteúdo enquanto o bot cuida do resto."
                </p>
              </div>

              {/* Testimonial 3 */}
              <div className="bg-indigo-900/50 p-8 rounded-lg">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=100&q=80" 
                    alt="Avatar" 
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-bold">Pedro Alves</h4>
                    <p className="text-indigo-300 text-sm">Empresa de Software</p>
                  </div>
                </div>
                <p className="text-indigo-200">
                  "Usamos o DiscordAutomator para nosso suporte técnico e comunidade de desenvolvedores. A facilidade de configuração e a robustez das integrações são impressionantes."
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Perguntas Frequentes</h2>
              <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
                Encontre respostas para as perguntas mais comuns sobre nossa plataforma.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {/* FAQ Item 1 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">Preciso saber programar para usar a plataforma?</h3>
                <p className="text-indigo-200">
                  Não, nossa plataforma foi projetada para ser usada sem conhecimento de programação. Utilizamos uma interface visual de arrastar e soltar que torna a criação de bots acessível a todos.
                </p>
              </div>

              {/* FAQ Item 2 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">Posso migrar meu bot existente para a plataforma?</h3>
                <p className="text-indigo-200">
                  Sim, oferecemos ferramentas de migração que permitem transferir a configuração e funcionalidades do seu bot existente para nossa plataforma.
                </p>
              </div>

              {/* FAQ Item 3 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">Quais são os limites do plano gratuito?</h3>
                <p className="text-indigo-200">
                  O plano gratuito permite criar 1 bot para até 2 servidores, com acesso a templates básicos e funcionalidades essenciais. Para mais recursos, recomendamos nossos planos pagos.
                </p>
              </div>

              {/* FAQ Item 4 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">Como funciona a integração com GPT?</h3>
                <p className="text-indigo-200">
                  Nossa integração com GPT permite que seu bot gere respostas inteligentes e contextuais para perguntas dos usuários, crie conteúdo e ofereça assistência personalizada.
                </p>
              </div>

              {/* FAQ Item 5 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">A plataforma é segura?</h3>
                <p className="text-indigo-200">
                  Sim, priorizamos a segurança dos seus dados e do seu servidor. Utilizamos criptografia, seguimos as melhores práticas de segurança e nunca armazenamos informações sensíveis.
                </p>
              </div>

              {/* FAQ Item 6 */}
              <div className="bg-indigo-900/50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">Posso cancelar minha assinatura a qualquer momento?</h3>
                <p className="text-indigo-200">
                  Sim, você pode cancelar sua assinatura a qualquer momento. Não há contratos de longo prazo ou taxas de cancelamento.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-indigo-800">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-6">Pronto para revolucionar seu servidor Discord?</h2>
            <p className="text-xl text-indigo-200 max-w-3xl mx-auto mb-8">
              Junte-se a milhares de comunidades que já estão usando nossa plataforma para criar experiências incríveis no Discord.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <button className="px-8 py-4 rounded-md bg-white text-indigo-900 hover:bg-indigo-100 transition-colors font-bold text-lg">
                Começar Gratuitamente
              </button>
              <button className="px-8 py-4 rounded-md bg-transparent border-2 border-white text-white hover:bg-white/10 transition-colors font-bold text-lg">
                Agendar Demonstração
              </button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-indigo-950 py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <Bot className="h-6 w-6 text-indigo-300" />
                  <span className="text-xl font-bold">DiscordAutomator</span>
                </div>
                <p className="text-indigo-300 mb-4">
                  A plataforma mais completa para automatizar e gerenciar seu servidor Discord.
                </p>
                <div className="flex space-x-4">
                  <a href="#" className="text-indigo-300 hover:text-white transition-colors">
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                    </svg>
                  </a>
                  <a href="#" className="text-indigo-300 hover:text-white transition-colors">
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </a>
                  <a href="#" className="text-indigo-300 hover:text-white transition-colors">
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                    </svg>
                  </a>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4">Produto</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Recursos</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Templates</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Preços</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">FAQ</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4">Empresa</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Sobre Nós</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Blog</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Carreiras</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Contato</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4">Suporte</h3>
                <ul className="space-y-2">
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Documentação</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Tutoriais</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Status</a></li>
                  <li><a href="#" className="text-indigo-300 hover:text-white transition-colors">Comunidade</a></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-indigo-800 pt-8 mt-8 text-center">
              <p className="text-indigo-400">
                &copy; 2025 DiscordAutomator. Todos os direitos reservados.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}

export default App;