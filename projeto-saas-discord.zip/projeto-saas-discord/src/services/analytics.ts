import { Analytics } from '@vercel/analytics/react';

export function AnalyticsProvider({ children }) {
  return (
    <>
      {children}
      <Analytics />
    </>
  );
}

export function trackEvent(eventName: string, data: any) {
  // Implementar tracking de eventos
}

export const analytics = {
  async getBotMetrics(botId: string) {
    const response = await api.get(`/bots/${botId}/metrics`);
    return {
      commands: response.data.commands_used,
      users: response.data.unique_users,
      messages: response.data.messages_processed,
      uptime: response.data.uptime
    };
  }
}; 