import { OAuth2Client } from 'discord-oauth2';
import { discord } from './discord';

const oauth = new OAuth2Client({
  clientId: import.meta.env.VITE_DISCORD_CLIENT_ID,
  clientSecret: import.meta.env.VITE_DISCORD_CLIENT_SECRET,
  redirectUri: import.meta.env.VITE_DISCORD_REDIRECT_URI,
});

export async function loginWithDiscord() {
  const url = oauth.generateAuthUrl({
    scope: ['identify', 'email', 'guilds'],
  });
  window.location.href = url;
}

export const auth = {
  async login(code: string) {
    const tokenData = await discord.tokenRequest(code);
    const userData = await discord.getUser(tokenData.access_token);
    
    // Salvar no localStorage e context
    return { user: userData, token: tokenData };
  },

  async getGuilds(token: string) {
    return await discord.getUserGuilds(token);
  }
}; 