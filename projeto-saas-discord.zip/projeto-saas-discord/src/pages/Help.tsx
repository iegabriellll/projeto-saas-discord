import { Search, ChevronRight, Book, Video, MessageCircle, FileText } from 'lucide-react';

const helpCategories = [
  {
    title: 'Primeiros Passos',
    description: 'Guia básico para começar com seu bot Discord',
    icon: Book,
    articles: [
      {
        title: 'Criando seu Primeiro Bot',
        content: `
          1. Acesse o Portal de Desenvolvedores do Discord
          2. Crie uma nova aplicação
          3. Configure o bot na seção "Bot"
          4. Gere o token de autenticação
          5. Use nosso construtor visual para criar comandos
        `,
        link: '/help/creating-bot'
      },
      {
        title: 'Comandos Essenciais',
        content: `
          • /help - Lista todos os comandos disponíveis
          • /setup - Configura o bot no servidor
          • /permissions - Gerencia permissões
          • /welcome - Configura mensagens de boas-vindas
          • /moderation - Configura ferramentas de moderação
        `,
        link: '/help/essential-commands'
      },
      {
        title: 'Integrando ao Servidor',
        content: `
          1. Gere o link de convite no dashboard
          2. Configure as permissões necessárias
          3. Adicione o bot ao seu servidor
          4. Use o comando /setup para configuração inicial
        `,
        link: '/help/integration'
      }
    ]
  },
  {
    title: 'Recursos Avançados',
    description: 'Funcionalidades avançadas para seu bot',
    icon: Video,
    articles: [
      {
        title: 'Sistema de Níveis e XP',
        content: `
          • Sistema automático de XP por mensagens
          • Configuração de níveis e recompensas
          • Roles automáticas por nível
          • Comandos de ranking e leaderboard
          • Personalização de mensagens de level up
        `,
        link: '/help/leveling'
      },
      {
        title: 'Automação de Moderação',
        content: `
          • Filtros de spam e conteúdo inadequado
          • Sistema de avisos e punições
          • Auto-moderação de links e convites
          • Logs detalhados de ações
          • Quarentena para novos membros
        `,
        link: '/help/moderation'
      },
      {
        title: 'Integração com APIs',
        content: `
          • Webhooks personalizados
          • Integração com Twitch e YouTube
          • Notificações de GitHub
          • Sistema de tickets
          • Integrações customizadas
        `,
        link: '/help/api-integration'
      }
    ]
  },
  {
    title: 'FAQ',
    description: 'Dúvidas frequentes sobre a plataforma',
    icon: MessageCircle,
    articles: [
      {
        title: 'Limites e Restrições',
        content: `
          • Máximo de 100 comandos por bot
          • Até 100 servidores no plano gratuito
          • Rate limits da API do Discord
          • Limites de mensagens por minuto
          • Restrições de permissões
        `,
        link: '/help/limits'
      },
      {
        title: 'Problemas Comuns',
        content: `
          • Bot não responde aos comandos
          • Erros de permissão
          • Problemas de conexão
          • Comandos slash não aparecem
          • Logs não são registrados
        `,
        link: '/help/troubleshooting'
      },
      {
        title: 'Segurança e Privacidade',
        content: `
          • Armazenamento seguro de tokens
          • Criptografia de dados sensíveis
          • Política de privacidade
          • Conformidade com ToS do Discord
          • Backup e recuperação
        `,
        link: '/help/security'
      }
    ]
  },
  {
    title: 'Documentação Técnica',
    description: 'Documentação detalhada para desenvolvedores',
    icon: FileText,
    articles: [
      {
        title: 'API Reference',
        content: `
          • Endpoints REST disponíveis
          • Autenticação e tokens
          • Rate limits e quotas
          • Formatos de resposta
          • Códigos de erro
        `,
        link: '/docs/api'
      },
      {
        title: 'Eventos do Discord',
        content: `
          • messageCreate
          • guildMemberAdd
          • interactionCreate
          • presenceUpdate
          • voiceStateUpdate
        `,
        link: '/docs/events'
      },
      {
        title: 'Melhores Práticas',
        content: `
          • Estrutura de comandos
          • Gerenciamento de cache
          • Tratamento de erros
          • Performance e otimização
          • Sharding para grandes bots
        `,
        link: '/docs/best-practices'
      }
    ]
  }
];

export function Help() {
  return (
    <div className="space-y-6">
      <div className="bg-indigo-900/50 p-6 rounded-lg">
        <h1 className="text-2xl font-bold mb-2">Central de Ajuda</h1>
        <p className="text-indigo-300 mb-6">
          Documentação completa e guias detalhados para criar e gerenciar seu bot Discord
        </p>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-indigo-400" />
          <input
            type="text"
            placeholder="Buscar na documentação..."
            className="w-full pl-10 pr-4 py-3 bg-indigo-800/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {helpCategories.map((category) => (
          <div key={category.title} className="bg-indigo-900/50 p-6 rounded-lg">
            <div className="flex items-start gap-4 mb-4">
              <div className="p-3 bg-indigo-800/50 rounded-lg">
                <category.icon className="h-6 w-6 text-indigo-300" />
              </div>
              <div>
                <h2 className="text-xl font-bold">{category.title}</h2>
                <p className="text-indigo-300">{category.description}</p>
              </div>
            </div>
            
            <ul className="space-y-2">
              {category.articles.map((article) => (
                <li key={article.title}>
                  <a
                    href={article.link}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-indigo-800/50 transition-colors group"
                  >
                    <div>
                      <span className="block font-medium">{article.title}</span>
                      <span className="text-sm text-indigo-300 hidden group-hover:block">
                        {article.content.split('\n')[1].trim()}
                      </span>
                    </div>
                    <ChevronRight className="h-5 w-5 text-indigo-400 group-hover:text-white transition-colors" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
} 