import React, { useState } from 'react';
import api from '../services/api';

export function Landing() {
  const [email, setEmail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Salvar email na waitlist
    await api.post('/waitlist', { email });
  };

  return (
    <div>
      <h1>DiscordAutomator - Em Breve</h1>
      <p>Crie bots para Discord sem código</p>
      <form onSubmit={handleSubmit}>
        <input 
          type="email" 
          placeholder="Seu email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit">
          Entrar na lista de espera
        </button>
      </form>
    </div>
  );
} 