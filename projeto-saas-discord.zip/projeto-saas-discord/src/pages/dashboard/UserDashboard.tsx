import { useState } from 'react';
import { BotList } from './BotList';
import { BotBuilder } from './BotBuilder';

export function UserDashboard() {
  const [selectedBot, setSelectedBot] = useState(null);

  return (
    <div className="flex h-screen">
      <aside className="w-64 bg-indigo-900 p-4">
        <BotList 
          onSelectBot={setSelectedBot}
          onCreateBot={() => setSelectedBot('new')}
        />
      </aside>

      <main className="flex-1 p-6">
        {selectedBot ? (
          <BotBuilder bot={selectedBot} />
        ) : (
          <div className="text-center mt-20">
            Selecione um bot para começar
          </div>
        )}
      </main>
    </div>
  );
} 