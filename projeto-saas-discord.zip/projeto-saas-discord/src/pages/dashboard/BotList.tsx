import { Plus } from 'lucide-react';

interface BotListProps {
  onSelectBot: (bot: any) => void;
  onCreateBot: () => void;
}

export function BotList({ onSelectBot, onCreateBot }: BotListProps) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Meus Bots</h2>
        <button
          onClick={onCreateBot}
          className="p-2 bg-indigo-600 rounded-full hover:bg-indigo-700"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      <div className="space-y-2">
        {/* Lista de bots será implementada aqui */}
        <div
          onClick={() => onSelectBot({ id: 1, name: 'Bot de Teste' })}
          className="p-4 bg-indigo-800/50 rounded-lg cursor-pointer hover:bg-indigo-800/70"
        >
          <h3 className="font-medium">Bot de Teste</h3>
          <p className="text-sm text-indigo-300">Online - 3 servidores</p>
        </div>
      </div>
    </div>
  );
} 