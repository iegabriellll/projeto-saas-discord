import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { CommandBlock } from '../../components/CommandBlock';

interface BotBuilderProps {
  bot: any;
}

export function BotBuilder({ bot }: BotBuilderProps) {
  return (
    <div className="h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{bot === 'new' ? 'Novo Bot' : bot.name}</h1>
      </div>

      <div className="h-full flex">
        <div className="w-64 bg-indigo-800/50 p-4 rounded-lg">
          <h3 className="text-lg font-bold mb-4">Blocos</h3>
          <div className="space-y-2">
            <CommandBlock type="message" />
            <CommandBlock type="reaction" />
            <CommandBlock type="moderation" />
            <CommandBlock type="custom" />
          </div>
        </div>

        <DragDropContext onDragEnd={() => {}}>
          <div className="flex-1 ml-6">
            <Droppable droppableId="flow">
              {(provided) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className="min-h-full bg-indigo-900/50 rounded-lg p-4"
                >
                  {/* Área onde os blocos serão soltos */}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        </DragDropContext>
      </div>
    </div>
  );
} 