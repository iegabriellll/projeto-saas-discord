import { useState } from 'react';
import { BarChart as BarChartIcon, Users, Bot, ArrowUp, ArrowDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Seg', users: 400, bots: 240 },
  { name: 'Ter', users: 300, bots: 139 },
  { name: 'Qua', users: 200, bots: 980 },
  { name: 'Qui', users: 278, bots: 390 },
  { name: 'Sex', users: 189, bots: 480 },
  { name: 'Sab', users: 239, bots: 380 },
  { name: 'Dom', users: 349, bots: 430 },
];

export function Analytics() {
  const [timeframe, setTimeframe] = useState('week');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Analytics</h1>
        <select 
          value={timeframe}
          onChange={(e) => setTimeframe(e.target.value)}
          className="bg-indigo-900/50 border border-indigo-800 rounded-lg px-4 py-2"
        >
          <option value="day">Hoje</option>
          <option value="week">Esta Semana</option>
          <option value="month">Este Mês</option>
          <option value="year">Este Ano</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Novos Usuários"
          value="1,234"
          change={12.5}
          icon={<Users className="h-6 w-6 text-indigo-300" />}
        />
        <MetricCard
          title="Bots Criados"
          value="567"
          change={-5.2}
          icon={<Bot className="h-6 w-6 text-indigo-300" />}
        />
        <MetricCard
          title="Taxa de Conversão"
          value="23%"
          change={8.1}
          icon={<BarChartIcon className="h-6 w-6 text-indigo-300" />}
        />
      </div>

      <div className="bg-indigo-900/50 rounded-lg p-6">
        <h2 className="text-xl font-bold mb-6">Crescimento</h2>
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: 'none',
                  borderRadius: '0.5rem',
                }}
              />
              <Bar dataKey="users" fill="#6366F1" name="Usuários" />
              <Bar dataKey="bots" fill="#8B5CF6" name="Bots" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, icon }: { 
  title: string; 
  value: string; 
  change: number;
  icon: React.ReactNode;
}) {
  const isPositive = change >= 0;

  return (
    <div className="bg-indigo-900/50 rounded-lg p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-indigo-300 mb-1">{title}</p>
          <h3 className="text-2xl font-bold">{value}</h3>
        </div>
        {icon}
      </div>
      <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
        {isPositive ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
        <span>{Math.abs(change)}%</span>
        <span className="text-indigo-300 ml-1">vs. período anterior</span>
      </div>
    </div>
  );
} 