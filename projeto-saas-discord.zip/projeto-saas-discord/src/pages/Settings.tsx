import { useState } from 'react';
import { Save } from 'lucide-react';

export function Settings() {
  const [settings, setSettings] = useState({
    notifications: true,
    emailUpdates: false,
    theme: 'dark',
    language: 'pt-BR'
  });

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Configurações</h1>

      <div className="max-w-2xl space-y-6">
        <div className="bg-indigo-900/50 p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-4">Preferências</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="font-medium">Notificações</label>
              <input
                type="checkbox"
                checked={settings.notifications}
                onChange={(e) => setSettings(s => ({ ...s, notifications: e.target.checked }))}
                className="toggle"
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="font-medium">Atualizações por Email</label>
              <input
                type="checkbox"
                checked={settings.emailUpdates}
                onChange={(e) => setSettings(s => ({ ...s, emailUpdates: e.target.checked }))}
                className="toggle"
              />
            </div>

            <div className="space-y-2">
              <label className="font-medium block">Tema</label>
              <select
                value={settings.theme}
                onChange={(e) => setSettings(s => ({ ...s, theme: e.target.value }))}
                className="w-full bg-indigo-800/50 px-4 py-2 rounded"
              >
                <option value="dark">Escuro</option>
                <option value="light">Claro</option>
                <option value="system">Sistema</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="font-medium block">Idioma</label>
              <select
                value={settings.language}
                onChange={(e) => setSettings(s => ({ ...s, language: e.target.value }))}
                className="w-full bg-indigo-800/50 px-4 py-2 rounded"
              >
                <option value="pt-BR">Português</option>
                <option value="en">English</option>
                <option value="es">Español</option>
              </select>
            </div>
          </div>

          <button className="mt-6 px-4 py-2 bg-indigo-600 rounded flex items-center gap-2 hover:bg-indigo-700">
            <Save className="h-4 w-4" />
            Salvar Alterações
          </button>
        </div>
      </div>
    </div>
  );
} 