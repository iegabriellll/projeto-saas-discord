import { useState, useEffect } from 'react';
import { 
  Users, Bot, Activity, 
  CreditCard, Settings 
} from 'lucide-react';
import { StatCard } from '../../components/StatCard';
import { ActivityChart } from '../../components/ActivityChart';
import { RecentUsers } from '../../components/RecentUsers';

export function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeBots: 0,
    monthlyRevenue: 0
  });

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Dashboard Admin</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          icon={<Users className="h-6 w-6 text-indigo-300" />}
          title="Usuários Ativos"
          value={stats.totalUsers}
        />
        <StatCard 
          icon={<Bot className="h-6 w-6 text-indigo-300" />}
          title="Bots Ativos"
          value={stats.activeBots}
        />
        <StatCard 
          icon={<CreditCard className="h-6 w-6 text-indigo-300" />}
          title="Receita Mensal"
          value={`R$ ${stats.monthlyRevenue}`}
        />
      </div>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <ActivityChart />
        <RecentUsers />
      </div>
    </div>
  );
} 